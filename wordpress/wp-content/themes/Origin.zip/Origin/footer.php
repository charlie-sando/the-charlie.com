			</div> <!-- #wrapper -->
		</div> <!-- #main -->
	</div> <!-- #main-wrap -->

	<?php wp_footer(); ?>
</body>
</html>